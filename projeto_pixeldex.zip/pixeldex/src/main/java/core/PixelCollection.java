
package core;

import ds.list.LinkedList;
import domain.Pixel;

public class PixelCollection {
    private LinkedList<Pixel> list = new LinkedList<>();

    public void add(Pixel p) { list.addLast(p); }
    public LinkedList<Pixel> getList() { return list; }
}
