
package core;

import ds.tree.BST;
import domain.Pixel;
import java.util.Comparator;

public class PixelIndex {
    private BST<Pixel> bst;

    public PixelIndex(Comparator<Pixel> comp) { this.bst = new BST<>(comp); }
    public void insert(Pixel p) { bst.insert(p); }
    public void remove(Pixel p) { bst.remove(p); }
    public Pixel search(Pixel p) { return bst.search(p); }
}
