package domain;

import java.util.Objects;

public class Pixel {
    private int id;
    private String nome;
    private Raridade raridade;
    private int poder;

    public enum Raridade { COMUM, INCOMUM, RARO, EPICO, LENDARIO }

    public Pixel(int id, String nome, Raridade raridade, int poder) {
        this.id = id;
        this.nome = nome;
        this.raridade = raridade;
        this.poder = poder;
    }

    public Pixel(int id, String nome) {
        this(id, nome, null, 0);
    }

    public Pixel(String nome) {
        this(0, nome, null, 0);
    }

    public int getId() { return id; }
    public String getNome() { return nome; }
    public Raridade getRaridade() { return raridade; }
    public int getPoder() { return poder; }

    public void setId(int id) { this.id = id; }
    public void setNome(String nome) { this.nome = nome; }
    public void setRaridade(Raridade raridade) { this.raridade = raridade; }
    public void setPoder(int poder) { this.poder = poder; }

    @Override
    public String toString() {
        return "Pixel(" + id + ", " + nome + ", " + raridade + ", " + poder + ")";
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Pixel)) return false;
        Pixel pixel = (Pixel) o;
        String a = (nome == null) ? null : nome.toLowerCase();
        String b = (pixel.nome == null) ? null : pixel.nome.toLowerCase();
        return Objects.equals(a, b);
    }

    @Override
    public int hashCode() {
        return nome == null ? 0 : nome.toLowerCase().hashCode();
    }
}
