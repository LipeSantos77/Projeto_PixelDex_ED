
package ds.tree;

import java.util.Comparator;

public class BST<T> {
    private BSTNode<T> root;
    private Comparator<T> comparator;

    public BST(Comparator<T> comparator) { this.comparator = comparator; }

    public void insert(T data) { root = insertRec(root, data); }

    private BSTNode<T> insertRec(BSTNode<T> node, T data) {
        if (node == null) return new BSTNode<>(data);
        int cmp = comparator.compare(data, node.data);
        if (cmp < 0) node.left = insertRec(node.left, data);
        else if (cmp > 0) node.right = insertRec(node.right, data);
        return node;
    }

    public T search(T key) { return searchRec(root, key); }

    private T searchRec(BSTNode<T> node, T key) {
        if (node == null) return null;
        int cmp = comparator.compare(key, node.data);
        if (cmp == 0) return node.data;
        return cmp < 0 ? searchRec(node.left, key) : searchRec(node.right, key);
    }

    public void remove(T key) { root = removeRec(root, key); }

    private BSTNode<T> removeRec(BSTNode<T> node, T key) {
        if (node == null) return null;
        int cmp = comparator.compare(key, node.data);
        if (cmp < 0) node.left = removeRec(node.left, key);
        else if (cmp > 0) node.right = removeRec(node.right, key);
        else {
            if (node.left == null) return node.right;
            if (node.right == null) return node.left;
            T minv = minValue(node.right);
            node.data = minv;
            node.right = removeRec(node.right, node.data);
        }
        return node;
    }

    private T minValue(BSTNode<T> node) {
        T minv = node.data;
        while (node.left != null) { minv = node.left.data; node = node.left; }
        return minv;
    }

    public void inOrder() { inOrderRec(root); }
    private void inOrderRec(BSTNode<T> node) {
        if (node != null) {
            inOrderRec(node.left);
            System.out.println(node.data);
            inOrderRec(node.right);
        }
    }

    public void preOrder() { preOrderRec(root); }
    private void preOrderRec(BSTNode<T> node) {
        if (node != null) {
            System.out.println(node.data);
            preOrderRec(node.left);
            preOrderRec(node.right);
        }
    }

    public void postOrder() { postOrderRec(root); }
    private void postOrderRec(BSTNode<T> node) {
        if (node != null) {
            postOrderRec(node.left);
            postOrderRec(node.right);
            System.out.println(node.data);
        }
    }

    public int height() { return heightRec(root); }
    private int heightRec(BSTNode<T> node) {
        if (node == null) return -1;
        return 1 + Math.max(heightRec(node.left), heightRec(node.right));
    }

    public int countNodes() { return countNodesRec(root); }
    private int countNodesRec(BSTNode<T> node) {
        if (node == null) return 0;
        return 1 + countNodesRec(node.left) + countNodesRec(node.right);
    }



    public int countLeaves() {
        return countLeavesRec(root);
    }

    private int countLeavesRec(BSTNode<T> node) {
        if (node == null) return 0;
        if (node.left == null && node.right == null) return 1;
        return countLeavesRec(node.left) + countLeavesRec(node.right);
    }

    public boolean isBST() {
        return isBSTRec(root, null, null);
    }

    private boolean isBSTRec(BSTNode<T> node, T min, T max) {
        if (node == null) return true;
        if (min != null && comparator.compare(node.data, min) <= 0) return false;
        if (max != null && comparator.compare(node.data, max) >= 0) return false;
        return isBSTRec(node.left, min, node.data) && isBSTRec(node.right, node.data, max);
    }

    public void range(T min, T max) { rangeRec(root, min, max); }
    private void rangeRec(BSTNode<T> node, T min, T max) {
        if (node == null) return;
        if (comparator.compare(node.data, min) > 0) rangeRec(node.left, min, max);
        if (comparator.compare(node.data, min) >= 0 && comparator.compare(node.data, max) <= 0)
            System.out.println(node.data);
        if (comparator.compare(node.data, max) < 0) rangeRec(node.right, min, max);
    }
}
