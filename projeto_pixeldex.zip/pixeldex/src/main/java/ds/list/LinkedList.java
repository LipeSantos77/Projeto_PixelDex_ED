
package ds.list;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class LinkedList<T> implements Iterable<T> {
    private LinkedNode<T> head;
    private int size;

    public LinkedList() { head = null; size = 0; }

    public void addFirst(T data) {
        LinkedNode<T> newNode = new LinkedNode<>(data);
        newNode.next = head;
        head = newNode;
        size++;
    }

    public void addLast(T data) {
        if (head == null) { addFirst(data); return; }
        LinkedNode<T> current = head;
        while (current.next != null) current = current.next;
        current.next = new LinkedNode<>(data);
        size++;
    }

    public void reverse() {
        LinkedNode<T> prev = null;
        LinkedNode<T> current = head;
        LinkedNode<T> next = null;
        while (current != null) {
            next = current.next;
            current.next = prev;
            prev = current;
            current = next;
        }
        head = prev;
    }

    public void unique() {
        LinkedNode<T> current = head;
        while (current != null) {
            LinkedNode<T> runner = current;
            while (runner.next != null) {
                if (runner.next.data.equals(current.data)) {
                    runner.next = runner.next.next;
                    size--;
                } else {
                    runner = runner.next;
                }
            }
            current = current.next;
        }
    }

    @Override
    public Iterator<T> iterator() {
        return new Iterator<T>() {
            private LinkedNode<T> current = head;
            @Override public boolean hasNext() { return current != null; }
            @Override public T next() {
                if (!hasNext()) throw new NoSuchElementException();
                T data = current.data;
                current = current.next;
                return data;
            }
        };
    }

    public T get(int index) {
        if (index < 0 || index >= size) throw new IndexOutOfBoundsException("Índice inválido: " + index);
        LinkedNode<T> current = head;
        for (int i=0;i<index;i++) current = current.next;
        return current.data;
    }

    public void addAt(int index, T data) {
        if (index < 0 || index > size) throw new IndexOutOfBoundsException("Índice inválido");
        if (index == 0) { addFirst(data); return; }
        LinkedNode<T> prev = head;
        for (int i=0;i<index-1;i++) prev = prev.next;
        LinkedNode<T> newNode = new LinkedNode<>(data);
        newNode.next = prev.next;
        prev.next = newNode;
        size++;
    }

    public void removeAt(int index) {
        if (index < 0 || index >= size) throw new IndexOutOfBoundsException("Índice inválido");
        if (index == 0) {
            head = head.next;
        } else {
            LinkedNode<T> prev = head;
            for (int i=0;i<index-1;i++) prev = prev.next;
            prev.next = prev.next.next;
        }
        size--;
    }

    public void move(int fromIndex, int toIndex) {
        if (fromIndex < 0 || fromIndex >= size || toIndex < 0 || toIndex >= size) {
            throw new IndexOutOfBoundsException("Índices de origem ou destino inválidos.");
        }
        if (fromIndex == toIndex) return;
        T dataToMove = get(fromIndex);
        removeAt(fromIndex);
        addAt(toIndex, dataToMove);
    }

    public LinkedList<T> slice(int from, int to) {
        if (from < 0 || to > size || from > to) throw new IllegalArgumentException("Intervalo inválido");
        LinkedList<T> newList = new LinkedList<>();
        LinkedNode<T> current = head;
        int index = 0;
        while (current != null && index < to) {
            if (index >= from) newList.addLast(current.data);
            current = current.next;
            index++;
        }
        return newList;
    }



    public boolean isEmpty() {
        return size == 0;
    }

    public T removeFirst() {
        if (head == null) {
            throw new NoSuchElementException("Lista vazia");
        }
        T data = head.data;
        head = head.next;
        size--;
        return data;
    }

    public T removeLast() {
        if (head == null) {
            throw new NoSuchElementException("Lista vazia");
        }
        if (head.next == null) {
            return removeFirst();
        }
        LinkedNode<T> prev = head;
        LinkedNode<T> current = head.next;
        while (current.next != null) {
            prev = current;
            current = current.next;
        }
        T data = current.data;
        prev.next = null;
        size--;
        return data;
    }

    public int size() { return size; }
}
