package util;

import java.util.Comparator;
import domain.Pixel;

public class Comparators {

    public static Comparator<Pixel> byNameIgnoreCase() {
        return (p1, p2) -> {
            String a = (p1 == null || p1.getNome() == null) ? "" : p1.getNome();
            String b = (p2 == null || p2.getNome() == null) ? "" : p2.getNome();
            return a.compareToIgnoreCase(b);
        };
    }

    public static Comparator<Pixel> byName() {
        return byNameIgnoreCase();
    }
}
