package integration;

import domain.Pixel;
import ds.list.LinkedList;
import ds.tree.BST;
import org.junit.jupiter.api.Test;
import util.Comparators;
import static org.junit.jupiter.api.Assertions.*;

class FlowTest {

    @Test
    void testFullFlow() {
        //configuração
        LinkedList<Pixel> userList = new LinkedList<>();
        BST<Pixel> index = new BST<>(Comparators.byName);

        Pixel p1 = new Pixel(1, "Pikachu", Pixel.Raridade.COMUM, 10);
        Pixel p2 = new Pixel(2, "Charizard", Pixel.Raridade.RARO, 50);

        //2-Adicionar (Simula comando ADD)
        userList.addLast(p1);
        index.insert(p1);

        userList.addLast(p2);
        index.insert(p2);

        //3-verificações
        assertEquals(2, userList.size());
        assertNotNull(index.search(new Pixel("Pikachu"))); // Busca por dummy

        //4-Remover do Índice (Simula REMOVE-INDEX)
        index.remove(new Pixel("Pikachu"));
        assertNull(index.search(new Pixel("Pikachu")));

        // A lista do usuário ainda deve ter o Pikachu (pois são estruturas separadas, a menos que sincronize)
        assertEquals(2, userList.size());
    }
}