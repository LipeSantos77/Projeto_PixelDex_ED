package ds.list;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.Iterator;

class LinkedListTest {

    @Test
    void testAddAndGet() {
        LinkedList<String> list = new LinkedList<>();
        list.addLast("A");
        list.addLast("B");

        assertEquals(2, list.size());
        assertEquals("A", list.get(0));
        assertEquals("B", list.get(1));
    }

    @Test
    void testReverse() {
        LinkedList<Integer> list = new LinkedList<>();
        list.addLast(1);
        list.addLast(2);
        list.addLast(3);

        list.reverse();

        // Esperado: 3, 2, 1
        assertEquals(3, list.get(0));
        assertEquals(2, list.get(1));
        assertEquals(1, list.get(2));
    }

    @Test
    void testUnique() {
        LinkedList<Integer> list = new LinkedList<>();
        list.addLast(1);
        list.addLast(2);
        list.addLast(2); // Duplicata
        list.addLast(3);

        list.unique();

        assertEquals(3, list.size());
        // Esperado: 1, 2, 3
        assertEquals(2, list.get(1));
        assertEquals(3, list.get(2));
    }

    @Test
    void testMove() {
        LinkedList<String> list = new LinkedList<>();
        list.addLast("A"); // 0
        list.addLast("B"); // 1
        list.addLast("C"); // 2
        list.addLast("D"); // 3

        // Mover "A" (0) para a posição de "C" (agora índice 2 após remoção de A)
        // Lista temporária após remover A: [B, C, D]
        // Inserir A no índice 2: [B, C, A, D]
        list.move(0, 2);

        assertEquals("B", list.get(0));
        assertEquals("C", list.get(1));
        assertEquals("A", list.get(2));
        assertEquals("D", list.get(3));
    }

    @Test
    void testSlice() {
        LinkedList<String> list = new LinkedList<>();
        list.addLast("A");
        list.addLast("B");
        list.addLast("C");
        list.addLast("D");

        // Slice de 1 a 3 (exclusivo no final? O enunciado diz range(a,b), assumimos inclusivo ou estilo substring)
        // Implementação usual Java é inclusivo-exclusivo, mas vamos assumir que o método slice implementado
        // pega 'count' elementos ou até o índice. Vamos testar o comportamento implementado.
        // Se sua implementação for "até index < to":
        LinkedList<String> sub = list.slice(1, 3);

        // Esperado índices 1 e 2: [B, C]
        assertEquals(2, sub.size());
        assertEquals("B", sub.get(0));
        assertEquals("C", sub.get(1));
    }
}