package ds.tree;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.Comparator;

class BSTTest {

    // Comparador simples de Inteiros para testar a estrutura lógica
    Comparator<Integer> intComparator = Integer::compareTo;

    @Test
    void testInsertAndSearch() {
        BST<Integer> bst = new BST<>(intComparator);
        bst.insert(10);
        bst.insert(5);
        bst.insert(15);

        assertEquals(10, bst.search(10));
        assertEquals(5, bst.search(5));
        assertNull(bst.search(99), "Deve retornar null para elemento inexistente");
    }

    @Test
    void testRemoveLeaf() { // Caso 1: Remover nó folha (sem filhos)
        BST<Integer> bst = new BST<>(intComparator);
        bst.insert(10);
        bst.insert(5); // Folha

        bst.remove(5);

        assertNull(bst.search(5));
        assertEquals(10, bst.search(10));
        assertEquals(1, bst.countNodes(), "Deve restar apenas 1 nó");
    }

    @Test
    void testRemoveOneChild() { // Caso 2: Remover nó com 1 filho
        BST<Integer> bst = new BST<>(intComparator);
        bst.insert(10);
        bst.insert(5);
        bst.insert(3); // 3 é filho de 5

        // Remover 5 (que tem o filho 3)
        bst.remove(5);

        assertNull(bst.search(5));
        assertEquals(3, bst.search(3), "O filho (3) deve ser preservado e reconectado ao avô (10)");
        assertEquals(2, bst.countNodes());
    }

    @Test
    void testRemoveTwoChildren() { // Caso 3: Remover nó com 2 filhos (o mais complexo)
        BST<Integer> bst = new BST<>(intComparator);
        bst.insert(10);
        bst.insert(5);  // Nó a remover
        bst.insert(3);  // Filho esq
        bst.insert(7);  // Filho dir

        // Estrutura:
        //      10
        //     /
        //    5
        //   / \
        //  3   7

        bst.remove(5);

        assertNull(bst.search(5));
        assertEquals(3, bst.search(3));
        assertEquals(7, bst.search(7));
        assertEquals(3, bst.countNodes());

        // Verificar se a ordem se mantém (3 < 7 < 10)
        // Uma travessia InOrder deve imprimir 3, 7, 10.
        // Aqui verificamos indiretamente pela busca.
    }

    @Test
    void testHeight() {
        BST<Integer> bst = new BST<>(intComparator);
        // Árvore vazia
        assertEquals(-1, bst.height());

        bst.insert(10); // Raiz (altura 0)
        assertEquals(0, bst.height());

        bst.insert(5);  // Nível 1
        assertEquals(1, bst.height());

        bst.insert(3);  // Nível 2
        assertEquals(2, bst.height());
    }
}