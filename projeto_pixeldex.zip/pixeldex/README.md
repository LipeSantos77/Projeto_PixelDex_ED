
# Pixeldex

Projeto Java (CLI) — Estruturas de dados feitas do zero:
- LinkedList genérica com reverse, unique, move, slice
- BST genérica com remoção completa, métricas e range
- CLI para interagir com a coleção e índice

Compilar:
```bash
cd src/main/java
# compilar recursivamente (ou use um build tool)
javac -d ../../../../out $(find . -name "*.java")
# executar
java -cp ../../../../out app.cli.Main
```
