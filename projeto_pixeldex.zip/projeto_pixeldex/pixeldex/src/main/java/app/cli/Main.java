package app.cli;

import java.util.Scanner;
import domain.Pixel;
import ds.list.LinkedList;
import ds.tree.BST;
import util.Comparators;
import java.util.Comparator;

public class Main {
    public static void main(String[] args) {
        Comparator<Pixel> pixelComparator = Comparators.byNameIgnoreCase();
        LinkedList<Pixel> userList = new LinkedList<>();
        BST<Pixel> globalIndex = new BST<>(pixelComparator);

        Scanner scanner = new Scanner(System.in);
        System.out.println("PixelDex CLI Iniciado. Digite HELP para comandos.");

        while (true) {
            System.out.print("> ");
            if (!scanner.hasNextLine()) break;
            String line = scanner.nextLine().trim();
            if (line.isEmpty()) continue;
            String[] parts = line.split("\\s+");
            String command = parts[0].toUpperCase();

            try {
                switch (command) {
                    case "ADD":
                        if (parts.length < 5) { System.out.println("Uso: ADD <id> <nome> <raridade> <poder>"); break; }
                        int id = Integer.parseInt(parts[1]);
                        String nome = parts[2];
                        Pixel.Raridade raridade = Pixel.Raridade.valueOf(parts[3].toUpperCase());
                        int poder = Integer.parseInt(parts[4]);
                        Pixel p = new Pixel(id, nome, raridade, poder);
                        userList.addLast(p);
                        globalIndex.insert(p);
                        System.out.println("OK: " + p + " adicionado");
                        break;

                    case "LIST":
                        if (userList.isEmpty()) {
                            System.out.println("Lista vazia.");
                        } else {
                            int index = 0;
                            for (Pixel px : userList) {
                                System.out.println("[" + (index++) + "] " + px);
                            }
                        }
                        break;

                    case "FIND":
                        if (parts.length < 2) { System.out.println("Uso: FIND <nome>"); break; }
                        Pixel busca = new Pixel(0, parts[1], null, 0);
                        Pixel encontrado = globalIndex.search(busca);
                        if (encontrado != null)
                            System.out.println("Encontrado: " + encontrado);
                        else
                            System.out.println("Não encontrado no índice.");
                        break;

                    case "REVERSE":
                        userList.reverse();
                        System.out.println("OK: Lista invertida");
                        break;

                    case "UNIQUE":
                        userList.unique();
                        System.out.println("OK: Duplicatas removidas da lista sequencial");
                        break;

                    case "REMOVE-COLLECTION":
                        if (parts.length < 2) { System.out.println("Uso: REMOVE-COLLECTION <index>"); break; }
                        int idxRemove = Integer.parseInt(parts[1]);
                        try {
                            userList.removeAt(idxRemove);
                            System.out.println("OK: Removido da posição " + idxRemove);
                        } catch (IndexOutOfBoundsException e) {
                            System.out.println("Erro: Índice fora dos limites.");
                        }
                        break;

                    case "REMOVE-INDEX":
                        // --- LÓGICA CORRIGIDA PARA REMOVER DE TUDO ---
                        if (parts.length < 2) { System.out.println("Uso: REMOVE-INDEX <nome>"); break; }
                        String nomeAlvo = parts[1];
                        Pixel pixelKey = new Pixel(0, nomeAlvo, null, 0);

                        // 1. Verifica e remove do Índice (BST)
                        Pixel target = globalIndex.search(pixelKey);
                        if (target == null) {
                            System.out.println("Erro: Pixel '" + nomeAlvo + "' não encontrado.");
                            break;
                        }
                        globalIndex.remove(pixelKey);

                        // 2. Procura e remove da Lista (LinkedList)
                        // Como LinkedList não tem um método remove(Objeto), achamos o índice na mão
                        int indexFound = -1;
                        int currentIndex = 0;
                        for (Pixel px : userList) {
                            // Compara ignorando maiúsculas/minúsculas
                            if (px.getNome().equalsIgnoreCase(nomeAlvo)) {
                                indexFound = currentIndex;
                                break;
                            }
                            currentIndex++;
                        }

                        if (indexFound != -1) {
                            userList.removeAt(indexFound);
                            System.out.println("OK: Removido da Lista (pos " + indexFound + ") e do Índice.");
                        } else {
                            System.out.println("Aviso: Removido do Índice, mas não foi achado na Lista (inconsistência).");
                        }
                        break;
                    // ---------------------------------------------

                    case "MOVE":
                        if (parts.length < 3) { System.out.println("Uso: MOVE <from> <to>"); break; }
                        int from = Integer.parseInt(parts[1]);
                        int to = Integer.parseInt(parts[2]);
                        userList.move(from, to);
                        System.out.println("OK: Movido de " + from + " para " + to);
                        break;

                    case "SLICE":
                        if (parts.length < 3) { System.out.println("Uso: SLICE <from> <to>"); break; }
                        int start = Integer.parseInt(parts[1]);
                        int end = Integer.parseInt(parts[2]);
                        LinkedList<Pixel> subList = userList.slice(start, end);
                        System.out.println("--- Slice [" + start + " - " + end + "] ---");
                        for (Pixel p2 : subList) System.out.println(p2);
                        break;

                    case "RANGE":
                        if (parts.length < 3) { System.out.println("Uso: RANGE <min> <max>"); break; }
                        Pixel minP = new Pixel(0, parts[1], null, 0);
                        Pixel maxP = new Pixel(0, parts[2], null, 0);
                        System.out.println("--- Range " + parts[1] + " até " + parts[2] + " ---");
                        globalIndex.range(minP, maxP);
                        break;

                    case "LIST-INDEX":
                        String mode = parts.length > 1 ? parts[1].toUpperCase() : "INORDER";
                        System.out.println("--- Índice Global (" + mode + ") ---");
                        if (mode.equals("PREORDER")) globalIndex.preOrder();
                        else if (mode.equals("POSTORDER")) globalIndex.postOrder();
                        else globalIndex.inOrder();
                        System.out.println("Métricas: Altura=" + globalIndex.height() + ", Nós=" + globalIndex.countNodes());
                        break;

                    case "HELP":
                        System.out.println("Comandos suportados: ADD, LIST, FIND, REVERSE, UNIQUE, REMOVE-COLLECTION, REMOVE-INDEX, MOVE, SLICE, RANGE, LIST-INDEX, HELP, EXIT");
                        break;

                    case "EXIT":
                        System.out.println("Saindo...");
                        scanner.close();
                        return;

                    default:
                        System.out.println("Comando desconhecido.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Erro: Argumento inválido (esperava-se um número).");
            } catch (Exception e) {
                System.out.println("Erro: " + e.getMessage());
            }
        }
    }
}